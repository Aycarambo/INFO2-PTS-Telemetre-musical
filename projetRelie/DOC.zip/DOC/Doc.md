# 2021-2022-Projet-Thérémine

## Sommaire
1. [Branchements](#branchement)
    1. [Schéma du branchement](#schema_branchement)
    2. [Photo du branchement](#photo_branchement)
2. [Séquence de lancement du programme](#lancement)
3. [Utilisation du logiciel](#logiciel)
    1. [Paramétrages](#parametrages)
    2. [Boutons et Images](#boutons_images)
    3. [Raccourcis Clavier](#raccourcis)
4. [Bibliothèques](#bibliotheques)
5. [LIDAR](#lidar)
    1. [Fonctionnement](#fonctionnement_lidar)
    2. [Utilisation](#utilisation_lidar)
<br>

## 1. Branchements <a name="branchement"></a>  
La carte Raspberry est connectée à plusieurs périphériques : 
- Un LIDAR TFmini-S
- Un clavier
- Une souris
- Un vidéo-projecteur
- Un chargeur

<br>

### 1.1 Schéma du branchement <a name="schema_branchement"></a>  
<img src="photo_branchement.png" title="Branchement Carte" width="450px;">

<br><br>

### 1.2 Photo du branchement <a name="photo_branchement"></a>  
<img src="branchement_lidar.png" title="Branchement LIDAR" width="450px;">

<br>

## 2. Séquence de lancement du programme <a name="lancement"></a>

<br>

## 3. Utilisation du logiciel <a name="logiciel"></a>

<br>

### 3.1 Paramétrages <a name="parametrages"></a>   

<br>

### 3.2 Boutons et Images <a name="boutons_images"></a>   

Affichage des notes :  
<img src="notes.png" title="Notes" width="450px;">

<br><br>

Une note est affichée selon 2 paramètres :
- La distance maximale et la distance minimale de détection du LIDAR [voir Paramétrages](#parametrages)
- La distance d'un objet captée par le LIDAR  

Une fréquence est en même temps jouée (correspondant à la note affichée)

<img src="table_frequences.png" title="Tables fréquences" width="450px;">

<br><br>

Choix de la gamme :  
<img src="gammes.png" title="Gammes" width="450px;">

<br><br>

Une gamme peut être choisie parmis les 3 gammes ci-dessus :
- Blues
- Mineure
- Japonaise

<br>

Démmarage/Arrêt musique :  
<img src="play_musique.png" title="Play Musique" width="450px;">

<br><br>

Une musique de fond peut être jouée ou arrêtée en appuyant sélectionnant le bouton Play/Stop

<br>

Volume de la muisque :  
<img src="volume.png" title="Volume" width="450px;">

<br><br>

Le volume de la musique de fond et de la note jouée peut être augmenté ou diminué en sélectionnant le slider "Volume"

<br>

Effet de reverb :  
<img src="reverb.png" title="Reverb" width="450px;">

<br><br>

La Reverb de la note jouée peut être augmenté ou diminué en sélectionnant le slider "Reverb"  

<br>

### 3.3 Raccourcis Clavier <a name="raccourcis"></a> 
Plusieurs raccourcis sont disponibles et permettent de naviguer plus facilement sur l'application :  

<img src="raccourcis_clavier.png" title="Reverb" width="450px;">
<br><br>

## 4. Bibliothèques <a name="bibliotheques"></a>

<br>

## 5. LIDAR <a name="lidar"></a>

### 5.1 Fonctionnement <a name="fonctionnement_lidar"></a>  

<a href="https://www.gotronic.fr/pj2-sj-pm-tfmini-s-a00-product-mannual-en-2155.pdf" title="Documentation technique">Documentation Lidar TFmini-S</a>

### 5.2 Utilisation <a name="utilisation_lidar"></a>